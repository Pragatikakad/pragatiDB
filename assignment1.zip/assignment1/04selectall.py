import pymysql


con=pymysql.connect(host='b3fpwxw4l5endkc7gqpd-mysql.services.clever-cloud.com', user='ulbgpnjcvltpaxof', password='XVMANurm6a0S5U1aYxkz',database='b3fpwxw4l5endkc7gqpd')
curs=con.cursor()

curs.execute("select * from Books")
data=curs.fetchall()

for rec in data:
  print(rec)

con.close()