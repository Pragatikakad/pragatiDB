import pymysql

try:
    con=pymysql.connect(host='b3fpwxw4l5endkc7gqpd-mysql.services.clever-cloud.com', user='ulbgpnjcvltpaxof', password='XVMANurm6a0S5U1aYxkz',database='b3fpwxw4l5endkc7gqpd')
    curs=con.cursor()
    bkcd=input("Enter the book code: ")
    bknm=input("Enter the Book Name: ")
    Cate=input("Enter the books category: ")
    author=input("ENter the Name of author of book: ")
    publ=input("Enter the name of publicatiopn: ")
    edition=input("Enter the edition of book: ")
    price=int(input("Enter the price of book: "))
    
    curs.execute("insert into Books values(%s,'%s','%s','%s','%s','%s',%d)" %(bkcd,bknm,Cate,author,publ,edition,price))
    con.commit()
    print("New Book is successfully Added")

    con.close()
except:
    print("failed")