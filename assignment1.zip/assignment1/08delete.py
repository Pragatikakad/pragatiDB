import pymysql


con=pymysql.connect(host='b3fpwxw4l5endkc7gqpd-mysql.services.clever-cloud.com', user='ulbgpnjcvltpaxof', password='XVMANurm6a0S5U1aYxkz',database='b3fpwxw4l5endkc7gqpd')
curs=con.cursor()

try:
    code=input("Enter book code : ")
    curs.execute("select * from Books where Bookcode='%s'" %code)
    data=curs.fetchone()
    if data:
        n=input("do you want to delete ?(yes / no)")
        if n.lower() =='yes':
            curs.execute("delete from Books where Bookcode='%s' " %code)
            con.commit()
            print("delete record successfully")
    else:
        print("Book does not found")
except Exception as e:
    print(e)                 
