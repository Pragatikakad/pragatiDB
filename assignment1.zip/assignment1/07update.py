import pymysql


con=pymysql.connect(host='b3fpwxw4l5endkc7gqpd-mysql.services.clever-cloud.com', user='ulbgpnjcvltpaxof', password='XVMANurm6a0S5U1aYxkz',database='b3fpwxw4l5endkc7gqpd')
curs=con.cursor()

try:
    code=input("Enter book code : ")
    curs.execute("select * from Books where Bookcode='%s'" %code)
    #data=curs.fetchone()
    nprice=int(input("Enter new price"))
    curs.execute("update Books set price=%d where Bookcode='%s'" %(nprice,code))
    con.commit()
    print("update successfully")
    con.close()
except Exception as e:
    print(e)    