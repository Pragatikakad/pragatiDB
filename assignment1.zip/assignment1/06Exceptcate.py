import pymysql

cat=input("Enter the category of Books you Want to see: ")
con=pymysql.connect(host='b3fpwxw4l5endkc7gqpd-mysql.services.clever-cloud.com', user='ulbgpnjcvltpaxof', password='XVMANurm6a0S5U1aYxkz',database='b3fpwxw4l5endkc7gqpd')
curs=con.cursor()

try:
  curs.execute("select * from Books where Category='%s' " %cat)
  data=curs.fetchall()
  print(data)

  con.close()

except Exception as e:
    print(e)  

